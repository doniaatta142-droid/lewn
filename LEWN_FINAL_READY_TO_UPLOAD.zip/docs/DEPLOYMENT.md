# Upload & Deploy
1. Unzip this project.
2. Upload all files/folders to your GitHub repository. Do not upload node_modules.
3. Backend: deploy the `backend` folder to a Node.js host and note its public URL.
4. Edit `frontend/js/api.js` and replace `http://localhost:3000/api` with `YOUR_BACKEND_URL/api`.
5. Deploy the `frontend` folder to GitHub Pages or another static host.
6. For production, add a real database, secure authentication, payment gateway, shipping integration, admin authorization, environment variables, validation, HTTPS and production CORS.
